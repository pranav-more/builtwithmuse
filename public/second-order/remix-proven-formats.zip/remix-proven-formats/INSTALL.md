# Install — Remix Proven Formats (a Second Order skill)

You need the folder named `remix-proven-formats` (it contains SKILL.md). Pick your setup:

## Claude.ai (browser or app)

1. Unzip the download if it is still zipped.
2. In Claude, open Settings → Capabilities → Skills.
3. Choose Upload skill and select the `remix-proven-formats` folder (or the zip, if your version asks for a zip).
4. Start a new chat and say: "Use the remix-proven-formats skill. I want to find outlier videos in my niche."
5. Claude will ask you for your setup details once — niche, channels you watch, your product, your audience, and your channel's typical views — then it runs the system with you.

## Claude Code

1. Unzip the download.
2. Copy the `remix-proven-formats` folder into `~/.claude/skills/` (create the folder if it does not exist).
3. Start Claude Code and ask it to find outliers, extract a format, generate clone scripts, or judge your results.

## What it does

- Ranks candidate videos by outlier multiple (views vs the channel's typical views) instead of raw views
- Breaks a winning video into a reusable format formula
- Writes 7 clone scripts, each changing exactly one element
- Judges your published clones against the strategy's expected return and updates the formula for the next round

From Second Order — one proven marketing strategy a day, with full step-by-step guides:
https://builtwithmuse.substack.com
